---
name: coo-flow-master
slug: "coo-flow-master"
version: 1.0.0
displayName: "运营副总全流程主入口"
summary: "一句话需求跑完 10 阶段 21 技能，产出 30 份文件并过十项硬门禁"
description: "当用户需要以运营副总视角把一句业务需求跑成完整运营方案时使用。本技能是全流程主入口，按顺序调度 10 个阶段共 21 个专项技能：S1 战略解码与目标定位（coo-advisor、company-os、strategic-alignment）→ S2 经营诊断与流程测绘（operations-data-diagnostician、process-mapper、cycle-time-analyzer）→ S3 目标拆解与指标体系（okr-cascade-designer、operations-kpi-designer）→ S4 资源负荷与产能规划（resource-load-planner、capacity-planner）→ S5 流程SOP与组织能力（operations-sop-builder、operations-role-capability-designer）→ S6 供应链与采购成本（vendor-management、procurement-optimizer）→ S7 项目协同与风控（operations-project-collaboration-planner、senior-pm）→ S8 质量管控与合规（quality-management、operations-compliance-account-diagnostician）→ S9 内部沟通与知识沉淀（internal-comms、knowledge-ops）→ S10 复盘引导与持续改进（operations-retrospective-facilitator）。引擎纯标准库零依赖、可离线、确定性可复现（同输入同输出），通过 init/run/status/gate 四个命令操作，gate 执行十项硬门禁（输入完整性、产物完整性、阶段覆盖、技能覆盖、数值合理性、文本完整性、责任闭环、指标闭环、确定性、无平台残留），任一不过即 REJECT 绝不带病交付。触发于"帮我做一套运营方案""运营全流程""COO 全流程""从战略到复盘跑一遍"等请求。"
tags: ["运营副总", "全流程", "COO", "自动化引擎", "硬门禁"]
---

# 运营副总全流程主入口

一句话需求 → 10 个阶段 → 21 个技能 → 30 份产物 → 十项硬门禁

## 一、这个技能解决什么问题

给你一句业务需求（如"我们是一家 60 人的电商公司，客服响应太慢，这个季度要提效"），
它跑完 **10 个阶段、21 个专项技能**，产出一套 30 份文件的完整运营方案，
并且每份产物都要过十项硬门禁。

不是给你一份"思路框架"，是给你可以直接拿去开会的表格、指标字典、SOP、里程碑和复测计划。

## 二、全流程调度表

| 阶段 | 名称 | 调度技能 | 核心产出 |
|---|---|---|---|
| S1 | 战略解码与目标定位 | coo-advisor、company-os、strategic-alignment | 目标重述、运营系统选型、四级对齐 |
| S2 | 经营诊断与流程测绘 | operations-data-diagnostician、process-mapper、cycle-time-analyzer | 流程阶段表、周期指标、瓶颈排序 |
| S3 | 目标拆解与指标体系 | okr-cascade-designer、operations-kpi-designer | OKR 表、四类指标、指标字典 |
| S4 | 资源负荷与产能规划 | resource-load-planner、capacity-planner | 负荷率、产能模型、招聘序列 |
| S5 | 流程SOP与组织能力 | operations-sop-builder、operations-role-capability-designer | 编号步骤 SOP、RACI、检查清单 |
| S6 | 供应链与采购成本 | vendor-management、procurement-optimizer | 支出分类、供应商分层、降本机会 |
| S7 | 项目协同与风控 | operations-project-collaboration-planner、senior-pm | 项目章程、里程碑、风险登记册 |
| S8 | 质量管控与合规 | quality-management、operations-compliance-account-diagnostician | 检查点、根因分析、合规健康度 |
| S9 | 内部沟通与知识沉淀 | internal-comms、knowledge-ops | 沟通矩阵、变更通知、知识分类 |
| S10 | 复盘引导与持续改进 | operations-retrospective-facilitator | 复盘报告、行动项、复测计划 |

## 三、四个命令

```bash
# 1. 初始化：把一句话需求解析成结构化档案
python scripts/coo_flow.py init --need "一句话业务需求" --out ./输出目录

# 2. 跑全流程：10 个阶段依次执行，产出 30 份文件
python scripts/coo_flow.py run --out ./输出目录

# 3. 看状态
python scripts/coo_flow.py status --out ./输出目录

# 4. 过门禁：十项判据，全绿才算交付
python scripts/coo_flow.py gate --out ./输出目录
```

## 四、需求怎么填（四级归一）

引擎会从你的一句话里识别四个字段，**绝不静默降级**：

| 字段 | 可用取值 | 识别方式 |
|---|---|---|
| 行业 | 电商 / SaaS / 制造 / 本地生活 / 内容服务 | 精确 → 同义词 → 最长子串 |
| 目标 | 降本 / 提效 / 增长 / 质量 / 合规 | 同上 |
| 规模 | 小型 / 中型 / 大型 | 同上；也支持从"60人"这类数字反推 |
| 周期 | 月度 / 季度 / 年度 | 同上 |

识别不出来会直接 REJECT 并打印可用取值清单，不会偷偷用默认值糊弄过去。
确实要强制执行时加 `--force`，此时会记录 `_raw` 原始输入与降级标记供追溯。

## 五、十项硬门禁

| 编号 | 判据 | 不通过的后果 |
|---|---|---|
| G01 | 输入完整性：行业/目标/规模/周期均已识别 | REJECT，打印可用取值 |
| G02 | 产物完整性：30 个阶段产物齐全 | REJECT |
| G03 | 阶段覆盖：10 个阶段全部执行 | REJECT |
| G04 | 技能覆盖：21 个技能全部调度 | REJECT |
| G05 | 数值合理性：无 NaN / Infinity | REJECT |
| G06 | 文本完整性：无乱码、无占位符 | REJECT |
| G07 | 责任闭环：行动项与里程碑均有唯一责任人 | REJECT |
| G08 | 指标闭环：每条指标含口径与责任人 | REJECT |
| G09 | 确定性：同输入两次运行产物哈希一致 | REJECT |
| G10 | 无平台残留：产物不含竞品与平台名 | REJECT |

**任一不过即 REJECT，绝不带病交付。**

## 六、产出清单（30 份）

- `00_交付索引.md` — 全流程索引（阶段 × 技能 × 产物）
- S1：战略解码报告.md、目标拆解.json、任务分解表.csv
- S2：经营诊断报告.md、流程阶段表.csv、周期指标.json
- S3：OKR与指标体系.md、OKR表.csv、指标字典.json
- S4：产能与负荷规划.md、产能模型.json、招聘序列.csv
- S5：SOP与岗位能力.md、SOP步骤表.csv、检查清单.md
- S6：采购与供应商优化.md、支出分类表.csv、采购成本模型.json
- S7：项目章程与风控.md、里程碑表.csv、风险登记册.json
- S8：质量与合规.md、缺陷分布表.csv、质量控制点.md
- S9：沟通与知识沉淀.md、变更通知_五段式.md、沟通日历.csv
- S10：复盘报告.md、行动项表.csv、复测计划.json

## 七、确定性怎么保证

所有"随机"数值都走 LCG（线性同余发生器），种子固定则结果固定：
**同样的需求 + 同样的种子 = 逐字节一致的产物**。
这样你可以放心把方案拿去评审，不必担心每次跑出来不一样。

换种子可以生成不同情景的对照方案：
`--seed 20250917` / `--seed 20250918`。

## 八、使用边界

- 不承诺固定业务结果；所有数值是基于你输入参数的结构化推演，需结合真实数据校准。
- 基线数据必须真实采集，不得虚构；缺失项在产物中标注为待验证。
- 涉及裁员、降薪、供应商违约等决策，本技能只给测算与结构，最终由人决定。
- 不输出任何平台名称、账号密码或身份敏感信息。
- 门禁通过只代表结构与完整性达标，业务适配性仍需负责人确认。


## 九、为什么要用主入口而不是逐个技能调用

逐个调用 21 个技能有三个问题：

1. **顺序容易乱** — 没做经营诊断就先定 KPI，指标一定定歪
2. **口径容易散** — 各技能各自假设基线与周期，最后数字对不上
3. **覆盖容易漏** — 凭感觉挑几个技能用，风险与合规环节常被跳过

主入口把顺序、口径和覆盖都固定下来：所有阶段共用同一份需求解析结果，
所有数值来自同一套确定性推演，所有阶段必须全部执行才能过门禁。

## 十、输出的方案能直接拿去干嘛

- **开经营会** — S1 的战略解码报告与 S3 的指标体系可直接进会议材料
- **做流程改造** — S2 的瓶颈排序与 S5 的 SOP 可直接交给流程负责人落地
- **谈人力预算** — S4 的负荷率与产能模型是申请编制的量化依据
- **管供应商** — S6 的支出分类与供应商分层可直接用于年度评审
- **推项目** — S7 的里程碑与风险登记册可直接作为项目启动材料
- **防风险** — S8 的检查点与合规健康度可直接转化为日常巡检动作
- **做变更沟通** — S9 的沟通矩阵与五段式通知可直接发出去
- **收尾复盘** — S10 的行动项与复测计划可直接用于季度复盘会

## 十一、常见用法示例

```
# 场景一：电商客服提效
python scripts/coo_flow.py init --need "60人电商公司，客服响应慢，本季度要提效" --out ./方案

# 场景二：制造企业降本
python scripts/coo_flow.py init --need "200人制造厂，采购成本高，今年要降本" --out ./方案

# 场景三：内容团队合规整改
python scripts/coo_flow.py init --need "MCN 机构账号多次违规，本季度要合规整改" --out ./方案

# 换种子生成对照方案
python scripts/coo_flow.py init --need "..." --out ./方案B --seed 20260101
```

---

淘宝店：AI灵匣 — 全套 AI 工作流技能包供应商
